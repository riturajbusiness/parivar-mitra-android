package com.parivarmitra.customer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
