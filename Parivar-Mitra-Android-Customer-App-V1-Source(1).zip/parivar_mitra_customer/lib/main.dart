import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/secure_store.dart';
import 'state/session_controller.dart';
import 'screens/auth_screen.dart';
import 'screens/app_shell.dart';

void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const ParivarMitraApp());}

class ParivarMitraApp extends StatelessWidget {
  const ParivarMitraApp({super.key});
  @override Widget build(BuildContext context){
    return ChangeNotifierProvider(
      create:(_)=>SessionController(const SecureStore())..initialize(),
      child:Consumer<SessionController>(builder:(context,s,_){
        final theme=ThemeData(
          useMaterial3:true,
          colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF0A8878),primary:const Color(0xFF0A8878),secondary:const Color(0xFF102E45),surface:const Color(0xFFF7FAFA)),
          scaffoldBackgroundColor:const Color(0xFFF5F9F9),
          appBarTheme:const AppBarTheme(backgroundColor:Colors.white,surfaceTintColor:Colors.transparent,elevation:0,foregroundColor:Color(0xFF0D2B42)),
          filledButtonTheme:FilledButtonThemeData(style:FilledButton.styleFrom(minimumSize:const Size(0,52),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)),textStyle:const TextStyle(fontWeight:FontWeight.w800))),
          outlinedButtonTheme:OutlinedButtonThemeData(style:OutlinedButton.styleFrom(minimumSize:const Size(0,50),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)))),
          inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:const BorderSide(color:Color(0xFFD7E4E3))),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:const BorderSide(color:Color(0xFFD7E4E3))),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:const BorderSide(color:Color(0xFF0A8878),width:1.5)),contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:15)),
        );
        return MaterialApp(debugShowCheckedModeBanner:false,title:'Parivar Mitra',theme:theme,builder:(context,child){final mq=MediaQuery.of(context);return MediaQuery(data:mq.copyWith(textScaler:TextScaler.linear(s.easyMode?1.15:1.0)),child:child??const SizedBox.shrink());},home:s.initializing?const _Splash():s.authenticated?const AppShell():const AuthScreen());
      })
    );
  }
}
class _Splash extends StatelessWidget {const _Splash();@override Widget build(BuildContext c)=>Scaffold(body:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Image.asset('assets/images/logo.png',width:78,height:78),const SizedBox(height:18),const CircularProgressIndicator()])));}
