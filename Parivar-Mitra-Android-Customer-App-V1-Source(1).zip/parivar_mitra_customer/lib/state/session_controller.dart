import 'package:flutter/foundation.dart';
import '../core/api_client.dart';
import '../core/config.dart';
import '../core/app_strings.dart';
import '../core/secure_store.dart';

class SessionController extends ChangeNotifier {
  String friendlyError(Object e){if(e is ApiException)return AppStrings.error(language,e.code,e.message);return e.toString();}
  final SecureStore store; late final ApiClient api;
  SessionController(this.store){api=ApiClient(store);}
  bool initializing=true; bool authenticated=false; bool busy=false; bool easyMode=false; String language='en'; Map<String,dynamic>? user; String? error;
  String? authEmail,challengeToken,verificationToken; bool needsProfile=false;
  Future<void> initialize() async {
    language=await store.read('language')??'en';easyMode=(await store.read('easy_mode'))=='1';final token=await store.read('access_token');
    if(token!=null){try{final d=await api.get('/me');user=(d['user'] as Map).cast<String,dynamic>();authenticated=true;}catch(_){authenticated=await api.refresh();if(authenticated){try{final d=await api.get('/me');user=(d['user'] as Map).cast<String,dynamic>();}catch(_){authenticated=false;}}}}
    initializing=false;notifyListeners();
  }
  Future<void> setEasyMode(bool enabled) async {easyMode=enabled;await store.write('easy_mode',enabled?'1':'0');notifyListeners();}
  Future<void> setLanguage(String lang) async {if(!['en','hi','mr'].contains(lang))return;language=lang;await store.write('language',lang);notifyListeners();if(authenticated){try{await api.patch('/me',body:{'preferred_language':lang,'full_name':user?['full_name']??''});}catch(_){}}}
  Future<bool> requestOtp(String email) async {busy=true;error=null;notifyListeners();try{final d=await api.post('/auth/request-otp',auth:false,body:{'email':email});authEmail=email.trim().toLowerCase();challengeToken=d['challenge_token']?.toString();needsProfile=false;return challengeToken!=null;}catch(e){error=friendlyError(e);return false;}finally{busy=false;notifyListeners();}}
  Future<String> verifyOtp(String code) async {busy=true;error=null;notifyListeners();try{final d=await api.post('/auth/verify-otp',auth:false,body:{'email':authEmail,'challenge_token':challengeToken,'code':code,'device_id':await store.deviceId(),'platform':'android','app_version':AppConfig.appVersion});needsProfile=d['needs_profile']==true;if(needsProfile){verificationToken=d['verification_token']?.toString();return 'profile';}await _saveSession(d);return 'done';}catch(e){error=friendlyError(e);return 'error';}finally{busy=false;notifyListeners();}}
  Future<bool> completeProfile(String name) async {busy=true;error=null;notifyListeners();try{final d=await api.post('/auth/complete-profile',auth:false,body:{'email':authEmail,'full_name':name,'verification_token':verificationToken,'terms_accepted':true,'privacy_accepted':true,'device_id':await store.deviceId(),'platform':'android','app_version':AppConfig.appVersion});await _saveSession(d);return true;}catch(e){error=friendlyError(e);return false;}finally{busy=false;notifyListeners();}}
  Future<void> _saveSession(dynamic d) async {final s=(d['session'] as Map).cast<String,dynamic>();await store.write('access_token',s['access_token']?.toString());await store.write('refresh_token',s['refresh_token']?.toString());user=(d['user'] as Map).cast<String,dynamic>();authenticated=true;authEmail=null;challengeToken=null;verificationToken=null;needsProfile=false;notifyListeners();}
  Future<void> logout() async {try{await api.post('/auth/logout');}catch(_){}await store.clearSession();authenticated=false;user=null;notifyListeners();}
}
