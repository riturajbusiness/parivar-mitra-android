import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_strings.dart';
import '../state/session_controller.dart';
import 'home_screen.dart';
import 'ai_screen.dart';
import 'book_screen.dart';
import 'services_screen.dart';
import 'more_screen.dart';

class AppShell extends StatefulWidget {const AppShell({super.key});@override State<AppShell> createState()=>_AppShellState();}
class _AppShellState extends State<AppShell>{int index=0;final pages=const [HomeScreen(),AiScreen(),BookScreen(),ServicesScreen(),MoreScreen()];@override Widget build(BuildContext context){final s=context.watch<SessionController>();String t(String k)=>AppStrings.t(s.language,k);return Scaffold(body:IndexedStack(index:index,children:pages),bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:[NavigationDestination(icon:const Icon(Icons.home_outlined),selectedIcon:const Icon(Icons.home),label:t('home')),NavigationDestination(icon:const Icon(Icons.auto_awesome_outlined),selectedIcon:const Icon(Icons.auto_awesome),label:t('ai')),NavigationDestination(icon:const Icon(Icons.add_circle_outline),selectedIcon:const Icon(Icons.add_circle),label:t('book')),NavigationDestination(icon:const Icon(Icons.grid_view_outlined),selectedIcon:const Icon(Icons.grid_view),label:t('services')),NavigationDestination(icon:const Icon(Icons.more_horiz),label:t('more'))]));}}
