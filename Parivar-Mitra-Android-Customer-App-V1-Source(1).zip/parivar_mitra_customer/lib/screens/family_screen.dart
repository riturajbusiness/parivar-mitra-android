import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_strings.dart';
import '../state/session_controller.dart';
import '../widgets/pm_widgets.dart';

class FamilyScreen extends StatefulWidget {
  const FamilyScreen({super.key});

  @override
  State<FamilyScreen> createState() => _FamilyScreenState();
}

class _FamilyScreenState extends State<FamilyScreen> {
  Future<dynamic>? future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    future ??= context.read<SessionController>().api.get('/family');
  }

  void refresh() {
    setState(() {
      future = context.read<SessionController>().api.get('/family');
    });
  }

  Future<void> addPerson() async {
    final name = TextEditingController();
    final relationship = TextEditingController();
    final area = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(AppStrings.t(context.read<SessionController>().language, 'addFamilyMember')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: InputDecoration(labelText: AppStrings.t(context.read<SessionController>().language, 'name'))),
            const SizedBox(height: 10),
            TextField(controller: relationship, decoration: InputDecoration(labelText: AppStrings.t(context.read<SessionController>().language, 'relationship'))),
            const SizedBox(height: 10),
            TextField(controller: area, decoration: InputDecoration(labelText: AppStrings.t(context.read<SessionController>().language, 'area'))),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(AppStrings.t(context.read<SessionController>().language, 'cancel'))),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(AppStrings.t(context.read<SessionController>().language, 'save'))),
        ],
      ),
    );

    if (ok == true) {
      try {
        await context.read<SessionController>().api.post(
          '/family/beneficiaries',
          body: {
            'name': name.text,
            'relationship': relationship.text,
            'area': area.text,
            'city': 'Pune',
          },
        );
        refresh();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.read<SessionController>().friendlyError(e))));
        }
      }
    }

    name.dispose();
    relationship.dispose();
    area.dispose();
  }

  Future<void> addProperty() async {
    final name = TextEditingController();
    final address = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(AppStrings.t(context.read<SessionController>().language, 'addProperty')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: InputDecoration(labelText: AppStrings.t(context.read<SessionController>().language, 'propertyName'))),
            const SizedBox(height: 10),
            TextField(controller: address, maxLines: 3, decoration: InputDecoration(labelText: AppStrings.t(context.read<SessionController>().language, 'address'))),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(AppStrings.t(context.read<SessionController>().language, 'cancel'))),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(AppStrings.t(context.read<SessionController>().language, 'save'))),
        ],
      ),
    );

    if (ok == true) {
      try {
        await context.read<SessionController>().api.post(
          '/family/properties',
          body: {'property_name': name.text, 'address': address.text},
        );
        refresh();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(context.read<SessionController>().friendlyError(e))));
        }
      }
    }

    name.dispose();
    address.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    String t(String key) => AppStrings.t(session.language, key);

    return Scaffold(
      appBar: AppBar(title: Text(t('family'))),
      body: FutureBuilder<dynamic>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Padding(
              padding: const EdgeInsets.all(18),
              child: ErrorBox(snapshot.error.toString()),
            );
          }

          final data = (snapshot.data as Map).cast<String, dynamic>();
          final people = (data['people'] as List?) ?? [];
          final properties = (data['properties'] as List?) ?? [];

          return RefreshIndicator(
            onRefresh: () async {
              refresh();
              await future;
            },
            child: ListView(
              padding: const EdgeInsets.all(18),
              children: [
                SectionTitle(
                  t('people'),
                  trailing: IconButton.filledTonal(onPressed: addPerson, icon: const Icon(Icons.add)),
                ),
                const SizedBox(height: 10),
                PmCard(
                  child: people.isEmpty
                      ? EmptyState(t('familyEmpty'))
                      : Column(
                          children: people.map((item) {
                            final person = (item as Map).cast<String, dynamic>();
                            final personName = (person['name'] ?? '?').toString();
                            final area = (person['area'] ?? '').toString();
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: CircleAvatar(child: Text(personName.substring(0, 1).toUpperCase())),
                              title: Text(personName, style: const TextStyle(fontWeight: FontWeight.w800)),
                              subtitle: Text('${person['relationship'] ?? t('familyDefault')}${area.isNotEmpty ? ' · $area' : ''}'),
                            );
                          }).toList(),
                        ),
                ),
                const SizedBox(height: 18),
                SectionTitle(
                  t('properties'),
                  trailing: IconButton.filledTonal(onPressed: addProperty, icon: const Icon(Icons.add)),
                ),
                const SizedBox(height: 10),
                PmCard(
                  child: properties.isEmpty
                      ? EmptyState(t('propertyEmpty'))
                      : Column(
                          children: properties.map((item) {
                            final property = (item as Map).cast<String, dynamic>();
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const CircleAvatar(child: Icon(Icons.home_outlined)),
                              title: Text(
                                (property['property_name'] ?? '').toString(),
                                style: const TextStyle(fontWeight: FontWeight.w800),
                              ),
                              subtitle: Text(
                                (property['address'] ?? '').toString(),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }).toList(),
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
