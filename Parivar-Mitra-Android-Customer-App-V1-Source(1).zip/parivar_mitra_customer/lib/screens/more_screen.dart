import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_strings.dart';
import '../state/session_controller.dart';
import 'requests_screen.dart';
import 'family_screen.dart';
import 'notifications_screen.dart';
import 'payments_screen.dart';
import 'family_summary_screen.dart';
import 'profile_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    String t(String key) => AppStrings.t(session.language, key);

    final items = <({IconData icon, String label, Widget screen})>[
      (icon: Icons.receipt_long_outlined, label: t('requests'), screen: const RequestsScreen()),
      (icon: Icons.family_restroom, label: t('family'), screen: const FamilyScreen()),
      (icon: Icons.payments_outlined, label: t('payments'), screen: const PaymentsScreen()),
      (icon: Icons.notifications_none, label: t('notifications'), screen: const NotificationsScreen()),
      (icon: Icons.summarize_outlined, label: t('summary'), screen: const FamilySummaryScreen()),
      (icon: Icons.person_outline, label: t('profile'), screen: const ProfileScreen()),
    ];

    return Scaffold(
      appBar: AppBar(title: Text(t('more'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: items.map((item) {
          return Card(
            child: ListTile(
              minVerticalPadding: 16,
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFEAF7F3),
                child: Icon(item.icon, color: const Color(0xFF0A8878)),
              ),
              title: Text(item.label, style: const TextStyle(fontWeight: FontWeight.w800)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => item.screen),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
