import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_strings.dart';
import '../state/session_controller.dart';
import '../widgets/pm_widgets.dart';
import 'book_screen.dart';

class RequestDetailScreen extends StatefulWidget {
  final int id;
  const RequestDetailScreen({super.key, required this.id});

  @override
  State<RequestDetailScreen> createState() => _RequestDetailScreenState();
}

class _RequestDetailScreenState extends State<RequestDetailScreen> {
  Future<dynamic>? future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    future ??= context.read<SessionController>().api.get('/requests/${widget.id}');
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    String t(String key) => AppStrings.t(session.language, key);

    return Scaffold(
      appBar: AppBar(title: Text(t('viewDetails'))),
      body: FutureBuilder<dynamic>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Padding(
              padding: const EdgeInsets.all(18),
              child: ErrorBox(snapshot.error.toString()),
            );
          }

          final data = (snapshot.data as Map).cast<String, dynamic>();
          final request = (data['request'] as Map).cast<String, dynamic>();
          final timeline = (data['timeline'] as List?) ?? [];
          final invoices = (data['invoices'] as List?) ?? [];
          final completion = data['completion_report'] as Map?;
          final quotedTotal = (request['quoted_total'] as num?) ?? 0;

          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              PmCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            AppStrings.service(session.language,(request['service_title'] ?? '').toString()),
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                          ),
                        ),
                        StatusPill((request['status'] ?? 'new').toString(),label:AppStrings.status(session.language,(request['status'] ?? 'new').toString())),
                      ],
                    ),
                    const SizedBox(height: 7),
                    Text(
                      (request['request_code'] ?? '').toString(),
                      style: const TextStyle(color: Color(0xFF0A8878), fontWeight: FontWeight.w700),
                    ),
                    const Divider(height: 24),
                    _row(Icons.person_outline, (request['requested_for_name'] ?? '').toString()),
                    _row(
                      Icons.location_on_outlined,
                      '${request['address'] ?? ''}, ${request['area'] ?? ''}, ${request['city'] ?? ''}',
                    ),
                    _row(Icons.schedule, (request['date'] ?? t('dateConfirm')).toString()),
                    if (quotedTotal > 0)
                      _row(Icons.currency_rupee, '${quotedTotal.toStringAsFixed(0)} ${t('estimated')}'),
                    if ((request['status'] ?? '').toString() == 'completed') ...[
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        onPressed: () async {
                          final result = await session.api.get('/requests/${widget.id}/repeat');
                          if (!context.mounted) return;
                          final draft = (result['draft'] as Map).cast<String, dynamic>();
                          final serviceId = draft['service_id'] as int?;
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => BookScreen(standalone: true, initialServiceId: serviceId),
                            ),
                          );
                        },
                        icon: const Icon(Icons.replay),
                        label: Text(t('bookAgain')),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 14),
              PmCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SectionTitle(t('timeline')),
                    const SizedBox(height: 12),
                    if (timeline.isEmpty)
                      EmptyState(t('serviceUpdates'))
                    else
                      ...timeline.reversed.map((item) {
                        final entry = (item as Map).cast<String, dynamic>();
                        return Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              children: [
                                Container(
                                  width: 12,
                                  height: 12,
                                  decoration: const BoxDecoration(color: Color(0xFF0A8878), shape: BoxShape.circle),
                                ),
                                Container(width: 2, height: 48, color: const Color(0xFFDCE8E6)),
                              ],
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(AppStrings.status(session.language,(entry['status']??'new').toString()), style: const TextStyle(fontWeight: FontWeight.w800)),
                                    if ((entry['notes'] ?? '').toString().isNotEmpty)
                                      Text((entry['notes'] ?? '').toString()),
                                    Text((entry['created_at'] ?? '').toString(), style: Theme.of(context).textTheme.bodySmall),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        );
                      }),
                  ],
                ),
              ),
              if (invoices.isNotEmpty) ...[
                const SizedBox(height: 14),
                PmCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SectionTitle(t('invoices')),
                      const SizedBox(height: 10),
                      ...invoices.map((item) {
                        final invoice = (item as Map).cast<String, dynamic>();
                        final total = (invoice['total'] as num?) ?? 0;
                        final due = (invoice['outstanding_amount'] as num?) ?? 0;
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text((invoice['invoice_no'] ?? '').toString()),
                          subtitle: Text('${AppStrings.status(session.language,(invoice['status']??'').toString())} · ₹${total.toStringAsFixed(0)}'),
                          trailing: Text('₹${due.toStringAsFixed(0)} ${t('due')}'),
                        );
                      }),
                    ],
                  ),
                ),
              ],
              if (completion != null) ...[
                const SizedBox(height: 14),
                PmCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SectionTitle(t('completionReport')),
                      const SizedBox(height: 8),
                      Text((completion['summary'] ?? '').toString()),
                      if ((completion['proof_summary'] ?? '').toString().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text((completion['proof_summary'] ?? '').toString()),
                      ],
                    ],
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _row(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 19, color: const Color(0xFF0A8878)),
          const SizedBox(width: 9),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
