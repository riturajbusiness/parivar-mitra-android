class AppStrings {
  static const supported = ['en', 'hi', 'mr'];
  static const labels = {'en': 'English', 'hi': 'हिन्दी', 'mr': 'मराठी'};
  static const Map<String, Map<String, String>> _v = {
    'en': {
      'app':'Parivar Mitra','tagline':'Trusted family assistance in Pune','signIn':'Sign in / Get Started','email':'Email address','continue':'Continue','sendCode':'Send secure login code','welcomeBack':'Welcome','otpTitle':'Check your email','otpHelp':'Enter the 6-digit code we sent to your email.','verify':'Verify & Continue','resend':'Resend code','name':'Full name','finish':'Finish setup','terms':'I agree to the Terms and Privacy Policy.','home':'Home','ai':'AI','book':'Book','services':'Services','more':'More','hello':'Good day','familyNeed':'What does your family need today?','askAi':'Ask Parivar Mitra AI','active':'Active','actionNeeded':'Action needed','completed':'Completed','family':'Family 360','notifications':'Notifications','profile':'Profile','requests':'My Services','payments':'Payments','summary':'Monthly Family Summary','logout':'Log out','quickServices':'Quick services','recentRequests':'Recent services','viewAll':'View all','noRequests':'No services yet.','starting':'Starting','requestHelp':'Request Assistance','description':'Describe what needs to be done','address':'Service address','area':'Area','city':'City','date':'Preferred date','time':'Preferred time','priority':'Priority','submit':'Submit request','normal':'Normal','high':'High','urgent':'Urgent non-emergency','person':'Person requiring assistance','relationship':'Relationship','selectService':'Select service','familyMember':'Family member','successRequest':'Your request has been submitted.','timeline':'Service timeline','status':'Status','noNotifications':'No notifications yet.','markAll':'Mark all read','language':'Language','easyMode':'Easy Mode','membership':'Membership','properties':'Properties','people':'Family members','addPerson':'Add family member','addProperty':'Add property','propertyName':'Property name','save':'Save','paymentHistory':'Payment history','invoices':'Invoices','recordedPayments':'Recorded payments','upcoming':'Upcoming','followUps':'Follow-ups','voice':'Speak','send':'Send','human':'Talk to Human','aiPlaceholder':'Tell us what your family needs…','refresh':'Refresh','retry':'Try again','loading':'Loading…','emailOnly':'Customer sign-in uses email verification. No password required.','newProfile':'Email verified. Tell us your name to finish setup.','secure':'Secure Customer Access','priceReview':'Final scope/payment will be confirmed by the Parivar Mitra team.','emergency':'Parivar Mitra is not an emergency service.','viewDetails':'View details','bookAgain':'Book again','support':'Support','settings':'Settings','addFamilyMember':'Add family member','addProperty':'Add property','cancel':'Cancel','enterManually':'Enter manually','specialInstructions':'Special instructions (optional)','noInvoices':'No invoices yet.','noPayments':'No payments recorded yet.','noActivity':'No activity recorded this month.','noFollowUps':'No follow-ups are currently recorded.','pincode':'Pincode','emergencyContact':'Emergency contact (optional)','profileSaved':'Profile saved.','completionReport':'Completion report','dateConfirm':'Date to be confirmed','estimated':'estimated','due':'due','familyEmpty':'Add parents or family members to speed up future bookings.','propertyEmpty':'Save a Pune property for faster inspections and maintenance requests.','serviceUpdates':'Service updates will appear here.','all':'All','sixDigitCode':'6-digit code','easyModeHelp':'Larger text and touch-friendly controls for easier use.','familyDefault':'Family','followUpDefault':'Follow-up','aiPromise':'AI understands. Humans coordinate. You stay informed.'
    },
    'hi': {
      'app':'Parivar Mitra','tagline':'पुणे में विश्वसनीय परिवार सहायता','signIn':'साइन इन / शुरू करें','email':'ईमेल पता','continue':'जारी रखें','sendCode':'सुरक्षित लॉगिन कोड भेजें','welcomeBack':'स्वागत है','otpTitle':'अपना ईमेल देखें','otpHelp':'ईमेल पर भेजा गया 6 अंकों का कोड दर्ज करें।','verify':'सत्यापित करें और आगे बढ़ें','resend':'कोड फिर भेजें','name':'पूरा नाम','finish':'सेटअप पूरा करें','terms':'मैं नियम और गोपनीयता नीति से सहमत हूँ।','home':'होम','ai':'एआई','book':'बुक करें','services':'सेवाएँ','more':'और','hello':'नमस्ते','familyNeed':'आज आपके परिवार को किस सहायता की आवश्यकता है?','askAi':'Parivar Mitra AI से पूछें','active':'सक्रिय','actionNeeded':'कार्रवाई आवश्यक','completed':'पूर्ण','family':'फैमिली 360','notifications':'सूचनाएँ','profile':'प्रोफ़ाइल','requests':'मेरी सेवाएँ','payments':'भुगतान','summary':'मासिक परिवार सारांश','logout':'लॉग आउट','quickServices':'त्वरित सेवाएँ','recentRequests':'हाल की सेवाएँ','viewAll':'सभी देखें','noRequests':'अभी कोई सेवा नहीं है।','starting':'शुरुआती','requestHelp':'सहायता का अनुरोध','description':'बताइए क्या करना है','address':'सेवा पता','area':'क्षेत्र','city':'शहर','date':'पसंदीदा तारीख','time':'पसंदीदा समय','priority':'प्राथमिकता','submit':'अनुरोध जमा करें','normal':'सामान्य','high':'उच्च','urgent':'तत्काल गैर-आपातकालीन','person':'जिस व्यक्ति को सहायता चाहिए','relationship':'रिश्ता','selectService':'सेवा चुनें','familyMember':'परिवार सदस्य','successRequest':'आपका अनुरोध जमा हो गया है।','timeline':'सेवा टाइमलाइन','status':'स्थिति','noNotifications':'अभी कोई सूचना नहीं है।','markAll':'सभी पढ़ा हुआ करें','language':'भाषा','easyMode':'आसान मोड','membership':'सदस्यता','properties':'संपत्तियाँ','people':'परिवार सदस्य','addPerson':'परिवार सदस्य जोड़ें','addProperty':'संपत्ति जोड़ें','propertyName':'संपत्ति का नाम','save':'सहेजें','paymentHistory':'भुगतान इतिहास','invoices':'चालान','recordedPayments':'दर्ज भुगतान','upcoming':'आगामी','followUps':'फॉलो-अप','voice':'बोलें','send':'भेजें','human':'मानव सहायता','aiPlaceholder':'बताइए आपके परिवार को क्या चाहिए…','refresh':'रीफ्रेश','retry':'फिर कोशिश करें','loading':'लोड हो रहा है…','emailOnly':'ग्राहक साइन-इन ईमेल सत्यापन से होता है। पासवर्ड आवश्यक नहीं।','newProfile':'ईमेल सत्यापित है। सेटअप पूरा करने के लिए अपना नाम बताइए।','secure':'सुरक्षित ग्राहक प्रवेश','priceReview':'अंतिम दायरा/भुगतान Parivar Mitra टीम पुष्टि करेगी।','emergency':'Parivar Mitra आपातकालीन सेवा नहीं है।','viewDetails':'विवरण देखें','bookAgain':'फिर बुक करें','support':'सहायता','settings':'सेटिंग्स','addFamilyMember':'परिवार सदस्य जोड़ें','addProperty':'संपत्ति जोड़ें','cancel':'रद्द करें','enterManually':'मैन्युअल रूप से दर्ज करें','specialInstructions':'विशेष निर्देश (वैकल्पिक)','noInvoices':'अभी कोई चालान नहीं है।','noPayments':'अभी कोई भुगतान दर्ज नहीं है।','noActivity':'इस महीने कोई गतिविधि दर्ज नहीं है।','noFollowUps':'अभी कोई फॉलो-अप दर्ज नहीं है।','pincode':'पिनकोड','emergencyContact':'आपातकालीन संपर्क (वैकल्पिक)','profileSaved':'प्रोफ़ाइल सहेजी गई।','completionReport':'पूर्णता रिपोर्ट','dateConfirm':'तारीख की पुष्टि बाकी है','estimated':'अनुमानित','due':'बकाया','familyEmpty':'भविष्य की बुकिंग आसान बनाने के लिए माता-पिता या परिवार सदस्य जोड़ें।','propertyEmpty':'निरीक्षण और रखरखाव के लिए पुणे की संपत्ति सहेजें।','serviceUpdates':'सेवा अपडेट यहाँ दिखाई देंगे।','all':'सभी','sixDigitCode':'6 अंकों का कोड','easyModeHelp':'आसान उपयोग के लिए बड़ा टेक्स्ट और स्पर्श-अनुकूल नियंत्रण।','familyDefault':'परिवार','followUpDefault':'फॉलो-अप','aiPromise':'AI समझता है। हमारी टीम स्थानीय समन्वय करती है। आप हर कदम से जुड़े रहते हैं।'
    },
    'mr': {
      'app':'Parivar Mitra','tagline':'पुण्यात विश्वासार्ह कुटुंब सहाय्य','signIn':'साइन इन / सुरुवात करा','email':'ईमेल पत्ता','continue':'पुढे जा','sendCode':'सुरक्षित लॉगिन कोड पाठवा','welcomeBack':'स्वागत आहे','otpTitle':'तुमचा ईमेल तपासा','otpHelp':'ईमेलवर पाठवलेला 6 अंकी कोड टाका.','verify':'पडताळा आणि पुढे जा','resend':'कोड पुन्हा पाठवा','name':'पूर्ण नाव','finish':'सेटअप पूर्ण करा','terms':'मी नियम व गोपनीयता धोरणास सहमत आहे.','home':'होम','ai':'एआय','book':'बुक करा','services':'सेवा','more':'अधिक','hello':'नमस्कार','familyNeed':'आज तुमच्या कुटुंबाला कोणती मदत हवी आहे?','askAi':'Parivar Mitra AI ला विचारा','active':'सक्रिय','actionNeeded':'कारवाई आवश्यक','completed':'पूर्ण','family':'फॅमिली 360','notifications':'सूचना','profile':'प्रोफाइल','requests':'माझ्या सेवा','payments':'पेमेंट','summary':'मासिक कुटुंब सारांश','logout':'लॉग आउट','quickServices':'त्वरित सेवा','recentRequests':'अलीकडील सेवा','viewAll':'सर्व पहा','noRequests':'अजून कोणतीही सेवा नाही.','starting':'सुरुवात','requestHelp':'सहाय्य विनंती','description':'काय करायचे आहे ते सांगा','address':'सेवेचा पत्ता','area':'परिसर','city':'शहर','date':'पसंतीची तारीख','time':'पसंतीची वेळ','priority':'प्राधान्य','submit':'विनंती जमा करा','normal':'सामान्य','high':'उच्च','urgent':'तातडीचे गैर-आपत्कालीन','person':'ज्यांना मदत हवी आहे','relationship':'नाते','selectService':'सेवा निवडा','familyMember':'कुटुंब सदस्य','successRequest':'तुमची विनंती जमा झाली आहे.','timeline':'सेवा टाइमलाइन','status':'स्थिती','noNotifications':'अजून कोणतीही सूचना नाही.','markAll':'सर्व वाचले म्हणून चिन्हांकित करा','language':'भाषा','easyMode':'सुलभ मोड','membership':'सदस्यत्व','properties':'मालमत्ता','people':'कुटुंब सदस्य','addPerson':'कुटुंब सदस्य जोडा','addProperty':'मालमत्ता जोडा','propertyName':'मालमत्तेचे नाव','save':'जतन करा','paymentHistory':'पेमेंट इतिहास','invoices':'चलने','recordedPayments':'नोंदवलेली पेमेंट','upcoming':'आगामी','followUps':'फॉलो-अप','voice':'बोला','send':'पाठवा','human':'मानवी सहाय्य','aiPlaceholder':'तुमच्या कुटुंबाला काय हवे आहे ते सांगा…','refresh':'रीफ्रेश','retry':'पुन्हा प्रयत्न करा','loading':'लोड होत आहे…','emailOnly':'ग्राहक साइन-इन ईमेल पडताळणीने होते. पासवर्ड आवश्यक नाही.','newProfile':'ईमेल पडताळला आहे. सेटअप पूर्ण करण्यासाठी नाव सांगा.','secure':'सुरक्षित ग्राहक प्रवेश','priceReview':'अंतिम व्याप्ती/पेमेंट Parivar Mitra टीम निश्चित करेल.','emergency':'Parivar Mitra आपत्कालीन सेवा नाही.','viewDetails':'तपशील पहा','bookAgain':'पुन्हा बुक करा','support':'सहाय्य','settings':'सेटिंग्स','addFamilyMember':'कुटुंब सदस्य जोडा','addProperty':'मालमत्ता जोडा','cancel':'रद्द करा','enterManually':'स्वतः माहिती भरा','specialInstructions':'विशेष सूचना (ऐच्छिक)','noInvoices':'अजून कोणतेही चलन नाही.','noPayments':'अजून कोणतेही पेमेंट नोंदलेले नाही.','noActivity':'या महिन्यात कोणतीही क्रिया नोंदलेली नाही.','noFollowUps':'सध्या कोणताही फॉलो-अप नोंदलेला नाही.','pincode':'पिनकोड','emergencyContact':'आपत्कालीन संपर्क (ऐच्छिक)','profileSaved':'प्रोफाइल जतन झाले.','completionReport':'पूर्णता अहवाल','dateConfirm':'तारीख निश्चित करायची आहे','estimated':'अंदाजे','due':'बाकी','familyEmpty':'पुढील बुकिंग जलद करण्यासाठी पालक किंवा कुटुंब सदस्य जोडा.','propertyEmpty':'तपासणी आणि देखभालीसाठी पुण्यातील मालमत्ता जतन करा.','serviceUpdates':'सेवा अपडेट येथे दिसतील.','all':'सर्व','sixDigitCode':'6 अंकी कोड','easyModeHelp':'सोप्या वापरासाठी मोठा मजकूर आणि स्पर्शास अनुकूल नियंत्रणे.','familyDefault':'कुटुंब','followUpDefault':'फॉलो-अप','aiPromise':'AI गरज समजते. आमची टीम स्थानिक समन्वय करते. तुम्ही प्रत्येक टप्प्यावर माहितीमध्ये राहता.'
    }
  };
  static String t(String lang,String key)=>_v[lang]?[key]??_v['en']?[key]??key;

  static String status(String lang,String status){
    const m={
      'new':{'en':'New','hi':'नया','mr':'नवीन'},
      'assigned':{'en':'Assigned','hi':'असाइन किया गया','mr':'नियुक्त'},
      'accepted':{'en':'Accepted','hi':'स्वीकृत','mr':'स्वीकारले'},
      'in_progress':{'en':'In progress','hi':'कार्य जारी','mr':'काम सुरू'},
      'on_hold':{'en':'On hold','hi':'रुका हुआ','mr':'स्थगित'},
      'completed':{'en':'Completed','hi':'पूर्ण','mr':'पूर्ण'},
      'cancelled':{'en':'Cancelled','hi':'रद्द','mr':'रद्द'},
      'payment_pending':{'en':'Payment pending','hi':'भुगतान बाकी','mr':'पेमेंट बाकी'},
      'quotation_sent':{'en':'Quotation sent','hi':'कोटेशन भेजा गया','mr':'कोटेशन पाठवले'},
      'customer_approval_pending':{'en':'Approval pending','hi':'स्वीकृति बाकी','mr':'मंजुरी बाकी'},
      'awaiting_customer_approval':{'en':'Approval pending','hi':'स्वीकृति बाकी','mr':'मंजुरी बाकी'},
      'customer_confirmation_pending':{'en':'Confirmation pending','hi':'पुष्टि बाकी','mr':'पुष्टी बाकी'},
      'disputed':{'en':'Needs review','hi':'समीक्षा आवश्यक','mr':'पुनरावलोकन आवश्यक'},
      'refunded':{'en':'Refunded','hi':'रिफंड किया गया','mr':'परतावा झाला'},
      'paid':{'en':'Paid','hi':'भुगतान किया गया','mr':'पेमेंट झाले'},
      'unpaid':{'en':'Unpaid','hi':'भुगतान बाकी','mr':'पेमेंट बाकी'},
      'partially_paid':{'en':'Partially paid','hi':'आंशिक भुगतान','mr':'अंशतः पेमेंट'},
      'pending':{'en':'Pending','hi':'लंबित','mr':'प्रलंबित'},
      'processing':{'en':'Processing','hi':'प्रक्रिया में','mr':'प्रक्रियेत'},
      'failed':{'en':'Failed','hi':'असफल','mr':'अयशस्वी'},
      'draft':{'en':'Draft','hi':'ड्राफ्ट','mr':'मसुदा'},
      'sent':{'en':'Sent','hi':'भेजा गया','mr':'पाठवले'},
      'void':{'en':'Void','hi':'रद्द','mr':'रद्द'},
    };
    return m[status]?[lang]??m[status]?['en']??status.replaceAll('_',' ');
  }

  static String error(String lang,String code,String fallback){
    const m={
      'invalid_email':{'en':'Enter a valid email address.','hi':'मान्य ईमेल पता दर्ज करें।','mr':'वैध ईमेल पत्ता टाका.'},
      'resend_too_soon':{'en':'Please wait a moment before requesting another code.','hi':'नया कोड मांगने से पहले थोड़ा इंतज़ार करें।','mr':'नवीन कोड मागण्यापूर्वी थोडे थांबा.'},
      'otp_rate_limited':{'en':'Too many code requests. Please try again later.','hi':'बहुत अधिक कोड अनुरोध हुए हैं। कृपया बाद में प्रयास करें।','mr':'खूप कोड विनंत्या झाल्या आहेत. कृपया नंतर पुन्हा प्रयत्न करा.'},
      'otp_invalid':{'en':'That code did not match. Please try again.','hi':'यह कोड सही नहीं है। फिर प्रयास करें।','mr':'हा कोड जुळला नाही. पुन्हा प्रयत्न करा.'},
      'otp_expired':{'en':'This code has expired. Request a new code to continue.','hi':'यह कोड समाप्त हो गया है। नया कोड मांगें।','mr':'हा कोड कालबाह्य झाला आहे. नवीन कोड मागा.'},
      'otp_attempt_limit':{'en':'Too many incorrect attempts. Request a new code.','hi':'बहुत अधिक गलत प्रयास हुए। नया कोड मांगें।','mr':'खूप चुकीचे प्रयत्न झाले. नवीन कोड मागा.'},
      'email_delivery_failed':{'en':'We could not send the email right now. Please try again shortly.','hi':'अभी ईमेल भेजा नहीं जा सका। थोड़ी देर बाद फिर प्रयास करें।','mr':'सध्या ईमेल पाठवता आला नाही. थोड्या वेळाने पुन्हा प्रयत्न करा.'},
      'customer_signin_only':{'en':'This sign-in is for Customer accounts only.','hi':'यह साइन-इन केवल ग्राहक खातों के लिए है।','mr':'हे साइन-इन फक्त ग्राहक खात्यांसाठी आहे.'},
      'authentication_required':{'en':'Please sign in to continue.','hi':'जारी रखने के लिए साइन इन करें।','mr':'पुढे जाण्यासाठी साइन इन करा.'},
      'invalid_session':{'en':'Your session ended. Please sign in again.','hi':'आपका सत्र समाप्त हो गया। कृपया फिर साइन इन करें।','mr':'तुमचे सत्र संपले आहे. कृपया पुन्हा साइन इन करा.'},
      'refresh_invalid':{'en':'Your session ended. Please sign in again.','hi':'आपका सत्र समाप्त हो गया। कृपया फिर साइन इन करें।','mr':'तुमचे सत्र संपले आहे. कृपया पुन्हा साइन इन करा.'},
      'consent_required':{'en':'Please accept the Terms and Privacy Policy to continue.','hi':'आगे बढ़ने के लिए नियम और गोपनीयता नीति स्वीकार करें।','mr':'पुढे जाण्यासाठी नियम आणि गोपनीयता धोरण स्वीकारा.'},
      'invalid_name':{'en':'Enter your full name to continue.','hi':'आगे बढ़ने के लिए अपना पूरा नाम दर्ज करें।','mr':'पुढे जाण्यासाठी तुमचे पूर्ण नाव टाका.'},
      'mobile_api_not_installed':{'en':'The app service is being configured. Please try again shortly.','hi':'ऐप सेवा कॉन्फ़िगर की जा रही है। थोड़ी देर बाद फिर प्रयास करें।','mr':'अॅप सेवा कॉन्फिगर होत आहे. थोड्या वेळाने पुन्हा प्रयत्न करा.'},
      'request_incomplete':{'en':'Please complete the required request details.','hi':'कृपया आवश्यक अनुरोध विवरण पूरा करें।','mr':'कृपया आवश्यक विनंती तपशील पूर्ण करा.'},
      'invalid_date':{'en':'Choose a valid future date.','hi':'मान्य आने वाली तारीख चुनें।','mr':'वैध पुढील तारीख निवडा.'},
      'invalid_time':{'en':'Choose a valid time.','hi':'मान्य समय चुनें।','mr':'वैध वेळ निवडा.'},
      'service_not_found':{'en':'Please choose an available service.','hi':'कृपया उपलब्ध सेवा चुनें।','mr':'कृपया उपलब्ध सेवा निवडा.'},
      'family_member_not_found':{'en':'That family member is not available on your account.','hi':'यह परिवार सदस्य आपके खाते में उपलब्ध नहीं है।','mr':'हा कुटुंब सदस्य तुमच्या खात्यात उपलब्ध नाही.'},
    };
    return m[code]?[lang]??m[code]?['en']??fallback;
  }

  static String service(String lang,String title){
    const m={
      'Hospital Assistance':{'hi':'अस्पताल सहायता','mr':'रुग्णालय सहाय्य'},
      'Doctor Appointment Assistance':{'hi':'डॉक्टर अपॉइंटमेंट सहायता','mr':'डॉक्टर अपॉइंटमेंट सहाय्य'},
      'Diagnostic & Medical Test Assistance':{'hi':'डायग्नोस्टिक और मेडिकल टेस्ट सहायता','mr':'डायग्नोस्टिक आणि मेडिकल टेस्ट सहाय्य'},
      'Medicine Collection':{'hi':'दवा संग्रह','mr':'औषध संकलन'},
      'Elderly Assistance':{'hi':'वरिष्ठ नागरिक सहायता','mr':'ज्येष्ठ नागरिक सहाय्य'},
      'Government Office Assistance':{'hi':'सरकारी कार्यालय सहायता','mr':'शासकीय कार्यालय सहाय्य'},
      'Banking Assistance':{'hi':'बैंकिंग सहायता','mr':'बँकिंग सहाय्य'},
      'Property Assistance':{'hi':'संपत्ति सहायता','mr':'मालमत्ता सहाय्य'},
      'Home Maintenance':{'hi':'घर रखरखाव','mr':'घर देखभाल'},
      'Emergency Family Assistance':{'hi':'तत्काल परिवार सहायता','mr':'तातडीचे कुटुंब सहाय्य'},
      'Custom Request':{'hi':'कस्टम अनुरोध','mr':'कस्टम विनंती'},
    };
    return lang=='en'?title:(m[title]?[lang]??title);
  }
}
