import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'secure_store.dart';

class ApiException implements Exception {
  final String code; final String message; final int status;
  ApiException(this.code,this.message,this.status);
  @override String toString()=>message;
}
class ApiClient {
  final SecureStore store; final http.Client _http;
  ApiClient(this.store,{http.Client? client}):_http=client??http.Client();
  Future<Map<String,String>> _headers({bool auth=true}) async {
    final h={'Accept':'application/json','Content-Type':'application/json','X-App-Version':AppConfig.appVersion,'X-Platform':AppConfig.platform,'X-Device-ID':await store.deviceId(),'X-App-Language':await store.read('language')??'en'};
    if(auth){final t=await store.read('access_token');if(t!=null)h['Authorization']='Bearer $t';}
    return h;
  }
  Uri _u(String path,[Map<String,String>? q])=>Uri.parse('${AppConfig.apiBaseUrl}$path').replace(queryParameters:q);
  Future<dynamic> get(String path,{Map<String,String>? query,bool auth=true})=>_send('GET',path,query:query,auth:auth);
  Future<dynamic> post(String path,{Map<String,dynamic>? body,bool auth=true})=>_send('POST',path,body:body,auth:auth);
  Future<dynamic> patch(String path,{Map<String,dynamic>? body,bool auth=true})=>_send('PATCH',path,body:body,auth:auth);
  Future<dynamic> _send(String method,String path,{Map<String,String>? query,Map<String,dynamic>? body,bool auth=true,bool retry=true}) async {
    final headers=await _headers(auth:auth);late http.Response r;final uri=_u(path,query);
    if(method=='GET')r=await _http.get(uri,headers:headers);else if(method=='PATCH')r=await _http.patch(uri,headers:headers,body:jsonEncode(body??{}));else r=await _http.post(uri,headers:headers,body:jsonEncode(body??{}));
    Map<String,dynamic> json={};try{json=(jsonDecode(r.body) as Map).cast<String,dynamic>();}catch(_){throw ApiException('invalid_response','The server returned an invalid response.',r.statusCode);}
    if(r.statusCode==401&&auth&&retry&&path!='/auth/refresh'){if(await refresh()){return _send(method,path,query:query,body:body,auth:auth,retry:false);}}
    if(r.statusCode<200||r.statusCode>=300||json['ok']!=true){final e=(json['error'] as Map?)?.cast<String,dynamic>()??{};throw ApiException(e['code']?.toString()??'request_failed',e['message']?.toString()??'Something went wrong.',r.statusCode);}
    return json['data'];
  }
  Future<bool> refresh() async {
    final refresh=await store.read('refresh_token');if(refresh==null)return false;
    try{final d=await post('/auth/refresh',auth:false,body:{'refresh_token':refresh,'device_id':await store.deviceId(),'platform':'android','app_version':AppConfig.appVersion});final s=(d['session'] as Map).cast<String,dynamic>();await store.write('access_token',s['access_token']?.toString());await store.write('refresh_token',s['refresh_token']?.toString());return true;}catch(_){await store.clearSession();return false;}
  }
}
