class AppConfig {
  static const String apiBaseUrl = 'https://parivarmitra.com/api/v2';
  static const String appVersion = '1.0.0';
  static const String platform = 'android';
}
