import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStore {
  const SecureStore();
  static const _s = FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
  Future<String?> read(String key)=>_s.read(key:key);
  Future<void> write(String key,String? value)=>value==null?_s.delete(key:key):_s.write(key:key,value:value);
  Future<void> clearSession() async {for(final k in ['access_token','refresh_token']){await _s.delete(key:k);}}
  Future<String> deviceId() async {
    var id=await read('device_id');
    if(id!=null&&id.isNotEmpty)return id;
    final r=Random.secure();final b=List<int>.generate(20,(_)=>r.nextInt(256));
    id='android-${DateTime.now().microsecondsSinceEpoch}-${b.map((e)=>e.toRadixString(16).padLeft(2,'0')).join()}';
    await write('device_id',id);return id;
  }
}
