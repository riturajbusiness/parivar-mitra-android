import 'package:flutter_test/flutter_test.dart';
import 'package:parivar_mitra_customer/core/app_strings.dart';

void main(){
  test('core labels exist in all supported languages',(){
    for(final lang in AppStrings.supported){
      for(final key in ['signIn','email','home','ai','book','services','family','notifications','profile']){
        expect(AppStrings.t(lang,key),isNotEmpty);
      }
    }
  });
  test('known services translate without blank values',(){
    expect(AppStrings.service('hi','Hospital Assistance'),isNotEmpty);
    expect(AppStrings.service('mr','Doctor Appointment Assistance'),isNotEmpty);
  });
}
