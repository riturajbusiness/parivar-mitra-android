import 'package:flutter_test/flutter_test.dart';
import 'package:parivar_mitra_customer/core/config.dart';

void main(){test('production API uses HTTPS',(){expect(AppConfig.apiBaseUrl.startsWith('https://'),isTrue);});}
